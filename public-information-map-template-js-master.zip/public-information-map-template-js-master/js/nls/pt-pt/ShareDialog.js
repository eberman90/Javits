define({
  "widgets": {
    "ShareDialog": {
      "title": "Partilhar",
      "heading": "Partilhar este mapa",
      "url": "Ligação de Mapa",
      "embed": "Integrar Mapa",
      "extent": "Partilhar a atual extensão do mapa",
      "size": "Tamanho (largura/altura):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Correio Eletrónico"
    }
  }
});