define({
  "widgets": {
    "ShareDialog": {
      "title": "Podijeli",
      "heading": "Podijeli kartu",
      "url": "Poveznica karte",
      "embed": "Ugradi kartu",
      "extent": "Podijeli trenutačni obuhvat karte",
      "size": "Veličina (širina/visina):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-pošta"
    }
  }
});