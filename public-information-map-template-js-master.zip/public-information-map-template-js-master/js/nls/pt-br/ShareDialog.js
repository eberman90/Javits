define({
  "widgets": {
    "ShareDialog": {
      "title": "Compartilhar",
      "heading": "Compartilhar este mapa",
      "url": "Link do Mapa",
      "embed": "Mapa Embutido",
      "extent": "Compartilhar extensão do mapa atual",
      "size": "Tamanho (largura/altura):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});