define({
  "widgets": {
    "ShareDialog": {
      "title": "共有",
      "heading": "このマップを共有",
      "url": "マップ リンク",
      "embed": "マップの埋め込み",
      "extent": "現在のマップ表示範囲の共有",
      "size": "サイズ (幅/高さ):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google+",
      "emailTooltip": "電子メール"
    }
  }
});