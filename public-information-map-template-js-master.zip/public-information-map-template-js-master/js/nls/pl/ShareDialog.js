define({
  "widgets": {
    "ShareDialog": {
      "title": "Udostępnij",
      "heading": "Udostępnij tę mapę",
      "url": "Łącze do mapy",
      "embed": "Osadź mapę",
      "extent": "Udostępnij zasięg bieżącej mapy",
      "size": "Rozmiar (szerokość/wysokość):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Email"
    }
  }
});