define({
  "widgets": {
    "ShareDialog": {
      "title": "แชร์",
      "heading": "แชร์แผนที่นี้",
      "url": "เชื่อมโยงแผนที่",
      "embed": "ผูกติดกับแผนที่",
      "extent": "แชร์ขอบเขตแผนที่ปัจจุบัน",
      "size": "ขนาด (กว้าง/สูง):",
      "facebookTooltip": "เฟสบุ๊ค",
      "twitterTooltip": "ทวิตเตอร์",
      "gplusTooltip": "กูเกิ้ลพลัส",
      "emailTooltip": "อีเมล์"
    }
  }
});