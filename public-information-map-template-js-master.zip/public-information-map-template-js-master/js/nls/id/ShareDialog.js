define({
  "widgets": {
    "ShareDialog": {
      "title": "Bagikan",
      "heading": "Bagikan peta ini",
      "url": "Tautan Peta",
      "embed": "Sematkan Peta",
      "extent": "Bagikan jangkauan peta saat ini",
      "size": "Ukuran (lebar/tinggi):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Email"
    }
  }
});