define({
  "widgets": {
    "ShareDialog": {
      "title": "Paylaş",
      "heading": "Bu haritayı paylaş",
      "url": "Harita Bağlantısı",
      "embed": "Haritayı Ekle",
      "extent": "Geçerli harita uzantısını paylaş",
      "size": "Boyut (genişlik/yükseklik):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-posta"
    }
  }
});