define({
  "widgets": {
    "ShareDialog": {
      "title": "Κοινοποίηση",
      "heading": "Κοινοποίηση αυτού του χάρτη",
      "url": "Σύνδεσμος χάρτη",
      "embed": "Ενσωμάτωση χάρτη",
      "extent": "Κοινοποίηση τρέχουσας έκτασης χάρτη",
      "size": "Μέγεθος (πλάτος/ύψος):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Email"
    }
  }
});